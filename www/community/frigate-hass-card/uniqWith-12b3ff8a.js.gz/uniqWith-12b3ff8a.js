import{c1 as o}from"./card-555679fd.js";function t(t,n){return n="function"==typeof n?n:void 0,t&&t.length?o(t,void 0,n):[]}export{t as u};
